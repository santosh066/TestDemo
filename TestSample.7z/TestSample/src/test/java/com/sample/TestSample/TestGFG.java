package com.sample.TestSample;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TestGFG 
{
	@Test
	public void testLongestWordLength()
	{
		assertEquals(12,GFG.LongestWordLength("i am bhavaniii"));
	}

}
