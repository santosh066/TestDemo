package com.sample.TestSample;

public class GFG {

	static int LongestWordLength(String str)
	{
		String[] words = str.split(" ");
		int length=0;
		String longestword = null;
		
		for(String word:words)
		{
			if(length < word.length())
			{
				length = word.length();
				longestword=word;
			}
		}
		System.out.println("longestword------>"+longestword);
		return length;
	}
	public static void main(String[] args) 
	{
		String str = "I am an intern at KJSAFDJSJF";
		
		System.out.println(LongestWordLength(str));
	}

}
